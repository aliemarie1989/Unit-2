package QuartsToGallonsInteractive;

import java.util.Scanner; 

public class QuartsToGallonsInteractive {
    public static void main(String[] args) {
    final int QUARTS_PER_GALLON = 4; 
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter the number of quarts needed: ");
            int quartsNeeded = scanner.nextInt();
            
            
            int gallons = quartsNeeded / QUARTS_PER_GALLON;
            int remainingQuarts = quartsNeeded % QUARTS_PER_GALLON;
            
System.out.println(gallons +
        "A job that needs " + quartsNeeded + " quarts requires " +
                " gallons plus " + remainingQuarts + " quarts.");
    } 
    }
}
