package QuartsToGallon;
//*******************************************
// Program Name: Quarts To Gallons
// Author: Aleisha Mari-Vializ
// Description: Declares a named constant to hold the number of quarts in a gallon (4)
//******************************************

public class QuartsToGallons {

public static void main(String[] args) { 
    final int QUARTS_PER_GALLON = 4; 
    int quartsNeeded = 18; 
    int gallons = quartsNeeded / QUARTS_PER_GALLON; 
    int remainingQuarts = quartsNeeded % QUARTS_PER_GALLON; 

    
System.out.println("A job that needs " + quartsNeeded + " quarts requires " + 
    gallons + " gallons plus " + remainingQuarts + " quarts.");
    }
}